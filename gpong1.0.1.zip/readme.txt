GPong, a clone of the '72 "Pong". Simple, elegant... classic.

Controls:
    A : up (P1)
    Z : down (P1)
    ' : up (P2)
    / : down (P2)
    P : pause
